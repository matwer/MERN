import React, { useEffect, useState } from "react";
import axios from "axios";

export default (props) => {
  // set up a local variable to store the product
  const [product, setProduct] = useState({});

  // when the page loads, load the product from the id sent in from props
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/products/" + props.id)
      .then((res) => setProduct(res.data));
  }, []);

  return (
    <div>
      <h3>Hello from ShowOneProduct</h3>
      <p>Product: {product.productName}</p>
      <p>Title: {product.productPrice}</p>
      <p>Product: {product.productDescription}</p>
    </div>
  );
};
