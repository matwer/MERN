// import React
import React from "react";
import { Link } from "@reach/router";

// make it look pretty(ish)
import "./productsCSS.css";

export default ({ products }) => {
  return (
    <>
      <div className="main">
        <h3>Products</h3>
        {products.map((product, i) => {
          return (
            <p key={i}>
              <Link to={"/products/" + product._id}>{product.productName}</Link>
            </p>
          );
        })}
      </div>
    </>
  );
};
