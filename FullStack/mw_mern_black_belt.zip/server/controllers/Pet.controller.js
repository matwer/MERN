// import the model
const Pet = require(`../models/Pet.model`);

// create & export the CRUD operations as an object
module.exports = {
  // create
  create: (req, res) => {
    const { petName, petType, petDescription } = req.body;
    Pet.create({
      petName,
      petType,
      petDescription,
    }) // runValidators runs automatically
      .then((newPet) => {
        console.log(newPet);
        res.json(newPet);
      })
      .catch((err) => res.status(400).json(err));
  },

  // findAll
  findAll: (req, res) => {
    Pet.find()
      .then((allPets) => {
        console.log(allPets);
        res.json(allPets);
      })
      .catch((err) => res.status(400).json(err));
  },

  // find One
  findOne: (req, res) => {
    Pet.findOne({ _id: req.params.id })
      .then((onePet) => {
        console.log(onePet);
        res.json(onePet);
      })
      .catch((err) => res.status(400).json(err));
  },

  // update
  findOneAndUpdate: (req, res) => {
    Pet.findOneAndUpdate({ _id: req.params.id }, req.body, {
      new: true,
      runValidators: true, // on update, run the validator
    })
      .then((updatedPet) => {
        console.log(updatedPet);
        res.json(updatedPet);
      })
      .catch((err) => res.status(400).json(err));
  },

  // delete
  deleteOne: (req, res) => {
    Pet.deleteOne({ _id: req.params.id })
      .then((result) => {
        console.log(result);
        res.json(result);
      })
      .catch((err) => res.status(400).json(err));
  },
};
