// import mongoose from node_modules
const mongoose = require(`mongoose`);

// create the db (like creating a schema in MySQL)
const PetSchema = new mongoose.Schema(
  {
    petName: {
      type: String,
      required: [true, `Pet name is required`],
      minLength: [3, `Pet name must be at least 3 characters`],
    },
    petType: {
      type: String,
      required: [true, `Pet type is required`],
      minLength: [3, `Pet type must be at least 3 characters`],
    },
    petDescription: {
      type: String,
      required: [true, `Pet description is required`],
      minLength: [3, `Pet description must be at least 3 characters`],
    },
  },
  { timestamps: true } // tracks createdAt, updatedAt
);

// create the mongoDB collection (like creating a table in MySQL)
const Pet = mongoose.model(`Pet`, PetSchema);

// export the model so it can be referenced for CRUD operations in the controller
module.exports = Pet;
