// pull in the queries from the controller
const {
  create,
  findOne,
  findAll,
  findOneAndUpdate,
  deleteOne,
} = require(`../controllers/Pet.controller`);

// export the routes to server.js
module.exports = (app) => {
  app.post("/api/pets", create);
  app.get("/api/pets/:id", findOne);
  app.get("/api/pets", findAll);
  app.put("/api/pets/:id", findOneAndUpdate);
  app.delete("/api/pets/:id", deleteOne);
};
