// import React, axios, Link & myCSS
import React, { useEffect, useState } from "react";
import { navigate } from "@reach/router";
import axios from "axios";
import "./myCSS.css";

const View = (props) => {
  console.log(props);
  // set up a local variable to store the pet
  const [pet, setPet] = useState({});

  // when the page loads, get the pet information
  useEffect(() => {
    axios
      .get("http://localhost:8000/api/pets/" + props.id)
      .then((res) => setPet(res.data));
  }, [props.id]);

  const adoptPet = (adoptedPetId) => {
    axios.delete("http://localhost:8000/api/pets/" + props.id).then((res) => {
      navigate("/");
    });
  };

  return (
    <div className="main">
      {/* <p className="viewPet"> */}
      <h3>Details about {pet.petName} </h3>
      {/* </p> */}
      <div className="details">
        <p>Type: {pet.petType}</p>
        <p>Description: {pet.petDescription}</p>
        <button onClick={() => adoptPet(pet._id)} id="adoptPet">
          Adopt {pet.petName}
        </button>
      </div>
    </div>
  );
};

export default View;
