// import React, axios, Link & myCSS
import React, { useState, useEffect } from "react";
import axios from "axios";
import { Link } from "@reach/router";
import "./myCSS.css";

const Main = (props) => {
  // console.log(props);
  // set up local variables for displaying the pets
  const [pets, setPets] = useState([]);

  useEffect(() => {
    getDataFromDB();
  }, []);

  const getDataFromDB = () => {
    axios
      .get("http://localhost:8000/api/pets")
      .then((res) => {
        console.log(res.data);
        let ordered = res.data;
        setPets(ordered.sort((a, b) => a.petType.localeCompare(b.petType)));
      })
      .catch((err) => console.log(err));
  };

  return (
    <div className="main">
      {/* <h3>Hello World! from Main.jsx!</h3> */}
      <h3>These pets are looking for a good home</h3>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Type</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {pets.map((pet, idx) => {
            return (
              <tr key={idx}>
                <td>{pet.petName}</td>
                <td>{pet.petType}</td>
                <td>
                  <p>
                    <button>
                      <Link to={"/pet/" + pet._id} className="btn">
                        Details
                      </Link>
                    </button>
                    |
                    <button>
                      <Link to={"/pet/edit/" + pet._id} className="btn">
                        Edit
                      </Link>
                    </button>
                  </p>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default Main;
