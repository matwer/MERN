// import React, axios, Link & myCSS
import React, { useState, useEffect } from "react";
import axios from "axios";
import { navigate } from "@reach/router";
import "./myCSS.css";

const Update = (props) => {
  // declare local variables to store the pet information
  const { id } = props;
  const [petName, setPetName] = useState("");
  const [petType, setPetType] = useState("");
  const [petDescription, setPetDescription] = useState("");

  // set up variables for front end and backend validations
  const [petNameError, setPetNameError] = useState("");
  const [petTypeError, setPetTypeError] = useState("");
  const [petDescriptionError, setPetDescriptionError] = useState("");
  const [dbErrors, setDBErrors] = useState([]);

  // frontend validation for petName
  const handlePetName = (e) => {
    // console.log(e.target.value);
    setPetName(e.target.value);

    if (e.target.value.length < 3) {
      setPetNameError("Pet name must be at least 3 characters");
    } else {
      setPetNameError("");
    }
  };

  // frontend validation for petType
  const handlePetType = (e) => {
    // console.log(e.target.value);
    setPetType(e.target.value);

    if (e.target.value.length < 3) {
      setPetTypeError("Pet type must be at least 3 characters");
    } else {
      setPetTypeError("");
    }
  };

  // frontend validation for petName
  const handlePetDescription = (e) => {
    // console.log(e.target.value);
    setPetDescription(e.target.value);

    if (e.target.value.length < 3) {
      setPetDescriptionError("Pet description must be at least 3 characters");
    } else {
      setPetDescriptionError("");
    }
  };

  // when the page loads, get the pet information
  useEffect(() => {
    axios.get("http://localhost:8000/api/pets/" + props.id).then((res) => {
      setPetName(res.data.petName);
      setPetType(res.data.petType);
      setPetDescription(res.data.petDescription);
    });
  }, [id]);

  // on submit, do the things
  const updatePet = (e) => {
    e.preventDefault();
    axios
      .put("http://localhost:8000/api/pets/" + id, {
        petName,
        petType,
        petDescription,
      })
      .then((res) => {
        console.log(res);
        navigate("/");
      })
      .catch((err) => {
        // get the errors from err.response.data & store them in an array
        const errorResponse = err.response.data.errors;
        const errorArr = [];
        // Loop through the error to get teh message
        for (const key of Object.keys(errorResponse)) {
          errorArr.push(errorResponse[key].message);
        }
        // set the errors
        setDBErrors(errorArr);
      });
  };

  return (
    <div className="main">
      {/* <h5>Hello World! from Update.jsx!</h5> */}
      {/* show frontend validation errors here */}
      {petNameError ? <p style={{ color: "red" }}>{petNameError}</p> : <p></p>}
      {petTypeError ? <p style={{ color: "red" }}>{petTypeError}</p> : <p></p>}
      {petDescriptionError ? (
        <p style={{ color: "red" }}>{petDescriptionError}</p>
      ) : (
        <p></p>
      )}

      {/* show backend validation errors here */}
      {dbErrors.map((err, i) => (
        <p className="errorMsg" key={i}>
          *** {err} ***
        </p>
      ))}
      <form onSubmit={updatePet}>
        <h3>Edit {petName}</h3>
        <p>
          <label htmlFor="petName">Pet name: </label>
          <br />
          <input
            type="text"
            name="petName"
            id="petName"
            value={petName} // needed for dbl binding
            placeholder="Add pet name (at least 3 characters)"
            onChange={handlePetName} // calls the fcn for frontend validations
          />
        </p>
        <p>
          <label htmlFor="petType">Pet type: </label>
          <br />
          <input
            type="text"
            name="petType"
            id="petType"
            value={petType} // needed for dbl binding
            placeholder="Add pet type (at least 3 characters)"
            onChange={handlePetType} // calls the fcn for frontend validations
          />
        </p>
        <p>
          <label htmlFor="petDescription">Pet description: </label>
          <br />
          <input
            type="text"
            name="petDescription"
            id="petDescription"
            value={petDescription} // needed for dbl binding
            placeholder="Describe pet (at least 3 characters)"
            onChange={handlePetDescription} // calls the fcn for frontend validations
          />
        </p>
        <input type="submit" value="Update" />
      </form>
    </div>
  );
};

export default Update;
