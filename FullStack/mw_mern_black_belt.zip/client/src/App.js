import "./App.css";

import React from "react";
import { Link, Router } from "@reach/router";

import Main from "./components/Main";
import Create from "./components/Create";
import View from "./components/View";
import Update from "./components/Update";

function App() {
  return (
    <div className="App">
      <h1>Pet Shelter</h1>
      <Link to="/">Home</Link> | <Link to="/pet/new">Add a pet</Link>
      <Router>
        <Update path="/pet/edit/:id" />
        <View path="/pet/:id" />
        <Create path="/pet/new" />
        <Main path="/" />
      </Router>
    </div>
  );
}

export default App;
