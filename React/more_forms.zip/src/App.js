
import './App.css';

import Login from './components/Login';

function App() {

  // display the input form
  return (    
    <div>
      <Login />
    </div>
  );
}

export default App;