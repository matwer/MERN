import React from 'react'

// display the failure page
const Failure = (props) => {
	return (
		<div>
			<img src="https://i.imgflip.com/2bc1xj.jpg" alt="These are not the droids you're looking for"/>
		</div>
	)
}

export default Failure;

