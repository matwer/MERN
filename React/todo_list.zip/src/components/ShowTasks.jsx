import React, {useState} from 'react';

const ShowTasks = (props => {
	return (
		<div>
			<h1> Hello from ShowTasks!</h1>
		</div>
	)
})

export default ShowTasks;